## logs README
This folder store the result of every training and testing