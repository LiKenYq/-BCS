import  torch
input = torch.randn([2,1,32,8,8])
print(input)
print(input.size())