# Dataset
import numpy as np
import torch
import torch.nn as nn

from scipy.io import loadmat
# HSI Dataset
"""
把非0的标签筛选出来，把标签位置索引保存label,把相应数据块索引保存到indices然后打乱

__getitem__ 随机提取一个数据块索引，然后根据patch判断是否再边界，然后根据位置再data中把相应的数据块提取出来以及从label把标签提出来
然后确定中心像素标签，return
"""
class HSI_Dataset(torch.utils.data.Dataset):
    def __init__(self, data, label, train, patch_size):
        """
        Args:
            data: 3D hyperspectral image
            gt: 2D array of labels
            patch_size: int, size of the spatial neighbourhood
            center_pixel: bool, set to True to consider only the label of the
                          center pixel
            data_augmentation: bool, set to True to perform random flips
        """
        super(HSI_Dataset, self).__init__()
        self.data = data
        self.label = label

        # self.ignored_labels = set(hyperparams["ignored_labels"])
        # self.flip_augmentation = hyperparams["flip_augmentation"]
        # self.radiation_augmentation = hyperparams["radiation_augmentation"]
        # self.mixture_augmentation = hyperparams["mixture_augmentation"]

        # self.center_pixel = hyperparams["center_pixel"]

        self.patch_size = patch_size
        # 就是把数据集按块分割然后得到当前块需要的标签
        # indices是位置索引   label是标签索引
        mask = np.ones_like(label)
        if train:
            mask[label == 0] = 0  # 对应位置调零

        x_pos, y_pos = np.nonzero(mask) # 找非零索引
        p = self.patch_size // 2
        # 只保存满足边界条件的非零的位置索引 然后把相应位置的label保存出来
        self.indices = np.array(
            [
                (x, y)
                for x, y in zip(x_pos, y_pos)
                if x > p and x < data.shape[0] - p and y > p and y < data.shape[1] - p # 确保提取图像块不超过边界
            ]
        )
        self.labels = [self.label[x, y] for x, y in self.indices]

        if train:
            np.random.shuffle(self.indices)
    # def flip(*arrays):
    #     horizontal = np.random.random() > 0.5
    #     vertical = np.random.random() > 0.5
    #     if horizontal:
    #         arrays = [np.fliplr(arr) for arr in arrays]
    #     if vertical:
    #         arrays = [np.flipud(arr) for arr in arrays]
    #     return arrays

    # def radiation_noise(data, alpha_range=(0.9, 1.1), beta=1 / 25):
    #     alpha = np.random.uniform(*alpha_range)
    #     noise = np.random.normal(loc=0.0, scale=1.0, size=data.shape)
    #     return alpha * data + beta * noise

    # def mixture_noise(self, data, label, beta=1 / 25):
    #     alpha1, alpha2 = np.random.uniform(0.01, 1.0, size=2)
    #     noise = np.random.normal(loc=0.0, scale=1.0, size=data.shape)
    #     data2 = np.zeros_like(data)
    #     for idx, value in np.ndenumerate(label):
    #         if value not in self.ignored_labels:
    #             l_indices = np.nonzero(self.labels == value)[0]
    #             l_indice = np.random.choice(l_indices)
    #             assert self.labels[l_indice] == value
    #             x, y = self.indices[l_indice]
    #             data2[idx] = self.data[x, y]
    #     return (alpha1 * data + alpha2 * data2) / (alpha1 + alpha2) + beta * noise

    def __len__(self):
        return len(self.indices)

    # 根据位置索引计算邻域空间范围，提取样本范围以及标签，储存在data 和 label中
    def __getitem__(self, i):
        x, y = self.indices[i]
        x1, y1 = x - self.patch_size // 2, y - self.patch_size // 2
        x2, y2 = x1 + self.patch_size, y1 + self.patch_size

        data = self.data[x1:x2, y1:y2]
        label = self.label[x1:x2, y1:y2]

        # if self.flip_augmentation and self.patch_size > 1:
        #     # Perform data augmentation (only on 2D patches)
        #     data, label = self.flip(data, label)
        # if self.radiation_augmentation and np.random.random() < 0.1:
        #     data = self.radiation_noise(data)
        # if self.mixture_augmentation and np.random.random() < 0.2:
        #     data = self.mixture_noise(data, label)

        # Copy the data into numpy arrays (PyTorch doesn't like numpy views)

        # 使用 np.copy 复制了数据 data 和 label，以确保不会修改原始数据。然后通过 transpose 方法重新排列了 data 的维度，将通道维度移动到了第一个位置
        # H, W, C转换为C, H, W
        data = np.asarray(np.copy(data).transpose((2, 0, 1)), dtype="float32")
        label = np.asarray(np.copy(label), dtype="int64")

        # Load the data into PyTorch tensors  加载数据
        data = torch.from_numpy(data)
        label = torch.from_numpy(label)

        # Extract the center label  提取中心标签
        if self.patch_size > 1:
            label = label[self.patch_size // 2, self.patch_size // 2]

        # Remove unused dimensions when we work with invidual spectrums
        elif self.patch_size == 1:
            data = data[:, 0, 0]
            label = label[0, 0]

        # Add a fourth dimension for 3D CNN
        if self.patch_size > 1:
            # Make 4D data ((Batch x) Planes x Channels x Width x Height)
            data = data.unsqueeze(0)
        
        return data, label

if __name__ == "__main__":
    image = loadmat(r".\\data\\15_image.mat")
    image = image["image_15"]
    label = loadmat(r".\\data\\15_label.mat")
    label = label["label_15"]
    train_dataset = HSI_Dataset(image, label)
    print(train_dataset.data)
